import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-banner-ad',
  templateUrl: './banner-ad.component.html',
  styleUrls: ['./banner-ad.component.scss']
})
export class BannerAdComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
