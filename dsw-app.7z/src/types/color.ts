export interface Color {
    id: number;
    displayName: string;
}